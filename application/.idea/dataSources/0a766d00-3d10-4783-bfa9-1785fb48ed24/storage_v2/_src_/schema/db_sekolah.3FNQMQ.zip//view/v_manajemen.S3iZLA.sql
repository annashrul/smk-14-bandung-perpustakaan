create view v_manajemen as
  select
    `tm`.`id`         AS `id`,
    `tm`.`nama`       AS `nama`,
    `tm`.`nip`        AS `nip`,
    `tm`.`jabatan`    AS `jabatan`,
    `tm`.`deskripsi`  AS `deskripsi`,
    `tm`.`image`      AS `image`,
    `tm`.`created_at` AS `created_at`,
    `tm`.`updated_at` AS `updated_at`,
    `tj`.`title`      AS `nama_jabatan`,
    `tm`.`matpel`     AS `matpel`
  from (`db_sekolah`.`tbl_manajemen` `tm`
    join `db_sekolah`.`tbl_jabatan` `tj` on ((`tj`.`id` = `tm`.`jabatan`)));

