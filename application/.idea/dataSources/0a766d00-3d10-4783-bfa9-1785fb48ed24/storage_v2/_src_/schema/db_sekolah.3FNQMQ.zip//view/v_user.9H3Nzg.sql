create view v_user as
  select
    `tu`.`id`           AS `id`,
    `tu`.`id_level`     AS `id_level`,
    `tu`.`nama`         AS `nama`,
    `tu`.`username`     AS `username`,
    `tu`.`password`     AS `password`,
    `tu`.`created_at`   AS `created_at`,
    `tu`.`updated_at`   AS `updated_at`,
    `tu`.`status`       AS `status`,
    `tl`.`title`        AS `level`,
    `tl`.`access_level` AS `access_level`,
    `tl`.`grant_access` AS `grant_access`
  from (`db_sekolah`.`tbl_user` `tu`
    join `db_sekolah`.`tbl_user_level` `tl` on ((`tl`.`id` = `tu`.`id_level`)));

