create view v_siswa as
  select
    `ts`.`id`            AS `id`,
    `ts`.`id_kelas`      AS `id_kelas`,
    `tk`.`id_jurusan`    AS `id_jurusan`,
    `ts`.`nama`          AS `nama`,
    `ts`.`nis`           AS `nis`,
    `ts`.`jenis_kelamin` AS `jenis_kelamin`,
    `ts`.`no_hp`         AS `no_hp`,
    `ts`.`alamat`        AS `alamat`,
    `tk`.`nama`          AS `kelas`,
    `tj`.`title`         AS `jurusan`,
    `ts`.`created_at`    AS `created_at`
  from ((`db_sekolah`.`tbl_siswa` `ts`
    join `db_sekolah`.`tbl_kelas` `tk` on ((`tk`.`id` = `ts`.`id_kelas`))) join `db_sekolah`.`tbl_jurusan` `tj`
      on ((`tj`.`id` = `tk`.`id`)));

